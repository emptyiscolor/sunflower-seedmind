#!/usr/bin/python3
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import atheris
import sys

with atheris.instrument_imports():
  from Crypto.Hash import (
    CMAC,
    HMAC,
    SHA224,
    SHA256,
    SHA384,
    SHA512,
    MD2,
    MD4,
    MD5,
    RIPEMD160
  )
  from Crypto.Cipher import AES



@atheris.instrument_func
def TestOneInput(data):
  fdp = atheris.FuzzedDataProvider(data)

  hashes = [
    SHA224,
    SHA256,
    SHA384,
    SHA512,
    MD2,
    MD4,
    MD5,
    RIPEMD160
  ]
  for f in hashes:
    h = f.new()
    h.update(data)
    h.digest

  h = HMAC.new(fdp.ConsumeBytes(9))
  h.update(data)
  h.digest

  try:
    cobj = CMAC.new(fdp.ConsumeBytes(16), ciphermod=AES)
    cobj.update(data)
  except ValueError as e:
    if "Key cannot be the null string" not in str(e):
      raise e



def main():
  atheris.Setup(sys.argv, TestOneInput, enable_python_coverage=True)
  atheris.Fuzz()

if __name__ == "__main__":
  main()
