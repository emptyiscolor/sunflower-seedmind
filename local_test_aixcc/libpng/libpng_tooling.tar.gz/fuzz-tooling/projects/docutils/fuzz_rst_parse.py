#!/usr/bin/python3
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import sys
import atheris

from docutils import parsers, frontend, utils, ApplicationError


def TestOneInput(data):
    fdp = atheris.FuzzedDataProvider(data)
    rst_parser_class = parsers.get_parser_class('rst')
    parser = rst_parser_class()
    document = utils.new_document(
        fdp.ConsumeUnicodeNoSurrogates(124),
        frontend.get_default_settings(parser)
    )
    try:
        parser.parse(fdp.ConsumeUnicodeNoSurrogates(sys.maxsize), document)
    except ApplicationError:
        pass


def main():
    atheris.instrument_all()
    atheris.Setup(sys.argv, TestOneInput, enable_python_coverage=True)
    atheris.Fuzz()


if __name__ == "__main__":
    main()

